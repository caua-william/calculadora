package br.fecap.ads.calculadoraimc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private Button btnSet, btnReset;
    private EditText campoAltura, campoPeso;
    private TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

// Inicializando os componentes
        btnSet = findViewById(R.id.btnSet);
        btnReset = findViewById(R.id.btnReset);
        campoAltura = findViewById(R.id.edittextAlt);
        campoPeso = findViewById(R.id.edittextPeso);
        textResultado = findViewById(R.id.texResultado);

// Configurando eventos dos botões
        btnSet.setOnClickListener(this::calculaIMC);
        btnReset.setOnClickListener(this::resetarCampos);
    }

    public void calculaIMC(View view) {
// Capturar os valores inseridos pelo usuário
        String alturaStr = campoAltura.getText().toString();
        String pesoStr = campoPeso.getText().toString();

// Verificar se os campos não estão vazios
        if (alturaStr.isEmpty() || pesoStr.isEmpty()) {
            Toast.makeText(this, "Por favor, insira valores válidos!", Toast.LENGTH_SHORT).show();
            return;
        }

// Converter os dados para Double
        double numAltura = Double.parseDouble(alturaStr);
        double numPeso = Double.parseDouble(pesoStr);

// Verificar se a altura é maior que zero
        if (numAltura <= 0) {
            Toast.makeText(this, "A altura deve ser maior que zero!", Toast.LENGTH_SHORT).show();
            return;
        }

// Calcular o IMC
        double numImc = numPeso / (numAltura * numAltura);

// Formatar o resultado para duas casas decimais
        DecimalFormat df = new DecimalFormat("0.00");
        String imcFormatado = df.format(numImc);

// Determinar a classificação do IMC
        String classificacao;
        if (numImc < 18.5) {
            classificacao = "Abaixo do peso";
        } else if (numImc < 24.9) {
            classificacao = "Peso normal";
        } else if (numImc < 29.9) {
            classificacao = "Sobrepeso";
        } else if (numImc < 34.9) {
            classificacao = "Obesidade Grau I";
        } else if (numImc < 39.9) {
            classificacao = "Obesidade Grau II";
        } else {
            classificacao = "Obesidade Grau III";
        }

// Exibir o resultado
        textResultado.setText("IMC: " + imcFormatado + " kg/m²\n" + classificacao);
    }

    public void resetarCampos(View view) {
// Limpa os campos de entrada e o resultado
        campoAltura.setText("");
        campoPeso.setText("");
        textResultado.setText("");
    }
}